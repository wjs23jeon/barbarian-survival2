바바리안: 미궁 생존기 - 안드로이드 APK 빌드 프로젝트

GitHub에 올린 뒤 Actions에서 APK를 무료로 빌드할 수 있습니다.

1. GitHub에서 새 Repository를 만듭니다 (Public 또는 Private).
2. 이 ZIP의 압축을 풀고, 안의 모든 파일/폴더를 저장소 최상위에 업로드합니다.
   중요: .github 폴더도 반드시 포함해야 합니다.
3. 저장소의 Actions 탭을 엽니다.
4. 왼쪽 'Build Barbarian APK'를 선택합니다.
5. 'Run workflow'를 눌러 빌드를 시작합니다.
6. 완료된 실행을 열고 아래 Artifacts에서 barbarian-survival-apk를 다운로드합니다.
7. ZIP 압축을 풀고 app-debug.apk를 갤럭시에 설치합니다.
   Android가 출처를 확인할 수 없는 앱 설치를 물으면 브라우저/파일 앱의 설치 허용을 켭니다.

이 빌드는 디버그 서명 APK입니다. 개인 기기에서 테스트/사용하기 위한 것입니다.
게임 저장은 앱 내부 WebView의 로컬 저장공간을 사용합니다.
